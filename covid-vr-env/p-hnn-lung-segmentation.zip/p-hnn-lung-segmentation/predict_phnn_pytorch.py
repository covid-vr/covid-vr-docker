#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  6 15:46:28 2017

@author: Adam P Harrison
adam.p.harrison@gmail.com

Progressive and Multi-Path Holistically Nested Neural Networks for Pathological Lung Segmentation from CT Images
"""

import load_hed_snapshot_share as l
import nibabel as nib
import numpy as np


def run_lung_segmentation(file_in, file_out, mean_file, offset, batch_size, model_weights, model_spec):

    ct_windows = np.array([[600, 1200], [1040, 400], [225, 450]])
    net = l.load_hed_net(model_spec, model_weights)

    volume = nib.load(file_in)
    v_data = np.squeeze(volume.get_fdata())
    mean_image = np.load(mean_file)

    result_data = l.run_volume_hed(
        net, v_data, mean_image, ct_windows, offset, batch_size)

    result = nib.Nifti1Image(
        result_data, volume.affine, volume.header)
    nib.save(result, file_out)

