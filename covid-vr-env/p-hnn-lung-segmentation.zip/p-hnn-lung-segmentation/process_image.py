from skimage import *
from skimage.segmentation import clear_border, mark_boundaries
from skimage.io import imread, imsave
import skimage.io
import numpy as np
import nibabel as nib
import matplotlib.pyplot as plt
import os
from glob import glob

def crop_3d_by_mask(file_in, file_mask_in, file_out):
    img_ori = nib.load(file_in)
    img_mask = nib.load(file_mask_in)
    
    data_ori = img_ori.get_fdata()
    data_mask = img_mask.get_fdata()
    bool_mask = data_mask > 0
    max_value = np.amax(data_ori)
    data_ori[~bool_mask] = max_value
    
    crop_img = nib.Nifti1Image(data_ori, img_ori.affine, img_ori.header)
    nib.save(crop_img, file_out)


def save_2d_slices(file_in, img_name, out_dir, sub_name):

    img = nib.load(file_in)
    data = img.get_fdata()

    #Axis 1
    axis_dir = out_dir + 'axis1/'
    if not os.path.exists(axis_dir): os.mkdir(axis_dir)
    sub_dir = axis_dir + sub_name 
    if not os.path.exists(sub_dir): os.mkdir(sub_dir)

    for i in range(data.shape[0]):
        ar_slice = data[i,:,:]
        skimage.io.imsave(sub_dir + str(img_name) + str(i+1)+'.jpeg', ar_slice)

    #Axis 2
    axis_dir = out_dir + 'axis2/'
    if not os.path.exists(axis_dir): os.mkdir(axis_dir)
    sub_dir = axis_dir + sub_name 
    if not os.path.exists(sub_dir): os.mkdir(sub_dir)
    
    for i in range(data.shape[1]):
        ar_slice = data[:,i,:]
        ar_slice = np.array(ar_slice, dtype=np.float32)
        skimage.io.imsave(sub_dir + str(img_name) + str(i+1)+'.jpeg', ar_slice)
    
    #Axis 3
    axis_dir = out_dir + 'axis3/'
    if not os.path.exists(axis_dir): os.mkdir(axis_dir)
    sub_dir = axis_dir + sub_name 
    if not os.path.exists(sub_dir): os.mkdir(sub_dir)
    
    for i in range(data.shape[2]):
        ar_slice = data[:,:,i]
        ar_slice = np.array(ar_slice, dtype=np.float32)
        skimage.io.imsave(sub_dir + str(img_name) + str(i+1)+'.jpeg', ar_slice)


def make_mb_image(i_img, i_gt, ds_op=lambda x: x[::1, ::1]):
    n_img = (i_img-i_img.mean())/(2*i_img.std())+0.5
    c_img = plt.cm.bone(n_img)[:, :, :3]
    i_gt = np.where(i_gt>200, 255, 0)
    c_img = mark_boundaries(c_img, label_img=ds_op(i_gt), color=(0, 1, 0), mode='thick')
    return c_img


def overlap_2d_by_mask(img_dir, img_mask_dir, output_dir):
    all_images = glob(img_dir + '*.jpeg')
    all_masks = ['mask'.join(c_file.split('original')) for c_file in all_images]
    it = 0
    for i_path, m_path in zip(all_images,all_masks):
        it += 1
        if it % 50 == 0: print(it)
        n_img=imread(i_path)
        n_mask=imread(m_path)

        imsave('line_masked'.join(i_path.split('original')),make_mb_image(n_img, n_mask))
    print('End overlap by mask')
