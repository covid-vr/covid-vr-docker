import predict_phnn_pytorch as ppp
import threshold_pmap as tpm
import process_image as pim
import dicom2nifti
from glob import glob
import os
import time


def run_lung_segmentation(nii_path, directory_out, mean_file, offset, batch_size, model_weights, model_spec, threshold):
    
    serie_id = nii_path.split('/')[-1] #serie_id.nii.gz
    if not serie_id.endswith('.nii.gz'):
        print('No nii file')
        return False
    
    if not os.path.exists(directory_out): 
        os.mkdir(directory_out)
    
    # lung_path = directory_out + serie_id + '.nii.gz'
    lung_path = nii_path 
    lung_prob_mask_path = f'{directory_out}/prob_mask_{serie_id}'
    lung_mask_path = f'{directory_out}/mask_{serie_id}'
    lung_crop_by_mask_path = f'{directory_out}/crop_by_mask_{serie_id}' 
            
    # run run_lung_segmentation
    # print('Begin: lung_segmentation get prob mask')
    time_init = time.time()
    ppp.run_lung_segmentation(lung_path, lung_prob_mask_path, mean_file, offset, batch_size, model_weights, model_spec)
    time_lapse = time.time() - time_init
    print('End: lung_segmentation get prob mask ' + str(time_lapse))
    #
    # run threshold_pmap.py 
    # print('Begin: get mask from prob mask')
    time_init = time.time()
    tpm.generate_threshold_pmap(lung_prob_mask_path, lung_mask_path, threshold)
    time_lapse = time.time() - time_init
    print('End: get mask from prob mask ' + str(time_lapse))
    #'''
    # run crop_3d_by_mask
    # print('Begin: crop 3D by mask')
    time_init = time.time()
    pim.crop_3d_by_mask(lung_path, lung_mask_path, lung_crop_by_mask_path)
    time_lapse = time.time() - time_init
    print('End: crop 3d by mask ' + str(time_lapse))
            

if __name__ == "__main__":
    import argparse
    import os
    parser = argparse.ArgumentParser(description='Run P-HNN on nii image.')

    parser.add_argument('--nii_path', type=str, required=True,
                        help='path to input .nii file')
    parser.add_argument('--directory_out', type=str, required=True,
                        help='path to output .nii file')
    parser.add_argument('--offset', type=int, required=False, default=1024,
                        help='offset to add to attenuation values (ONLY CHANGE IF YOU KNOW WHAT YOU\'RE DOING')
    parser.add_argument('--mean_file', type=str, required=False,
                        default='', help='location of mean file to use')
    parser.add_argument('--batch_size', type=int, required=False, default=5,
                        help='batch number of slices; higher number makes segmentation go faster, but requires more memory')
    parser.add_argument('--model_weights', type=str, required=False,
                        default='', help='Path to pytorch pth file')
    parser.add_argument('--model_spec', type=str, required=False,
                        default='', help='Path to model prototxt')
    parser.add_argument('--threshold', type=float, required=False,default=0.78,help='threshold for probability map, should be between 0 and 1s') 

    args = parser.parse_args()
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    print(cur_dir)
    mean_file = args.mean_file
    if mean_file == '':
        mean_file = os.path.join(
            cur_dir, 'train_colour_slice_list_0.lst_mean_image.npy')

    model_weights = args.model_weights
    if model_weights == '':
        model_weights = os.path.join(cur_dir, 'pytorch_model/pytorch_phnn.pth')

    model_spec = args.model_spec
    if model_spec == '':
        model_spec = os.path.join(cur_dir, 'deploy.prototxt')
    
    run_lung_segmentation(args.nii_path, args.directory_out, mean_file, args.offset, args.batch_size, model_weights, model_spec, args.threshold)

