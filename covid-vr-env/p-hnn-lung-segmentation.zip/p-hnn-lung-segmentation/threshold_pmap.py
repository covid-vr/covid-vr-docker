#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 14:13:44 2017

@author: Adam P Harrison
adam.p.harrison@gmail.com

Progressive and Multi-Path Holistically Nested Neural Networks for Pathological Lung Segmentation from CT Images
"""

def generate_threshold_pmap(file_in, file_out, threshold): 
    import argparse
    
    import mask_metrics_share as m
    import nibabel as nib
    import numpy as np
    
    volume=nib.load(file_in)
    v_data=np.squeeze(volume.get_data())
    result=m.threshold_mask(v_data,threshold)
    
    result=nib.Nifti1Image(result,volume.affine,volume.header)     
    nib.save(result,file_out)

